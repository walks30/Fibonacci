﻿// Serie FIbonacci - Foro de consultas - UNED

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fibonaci
{
    class ProgramaCompara
    {
        private static DateTime tiempo1;
        private static DateTime tiempo2;
        private static DateTime tiempo1r;
        private static DateTime tiempo2r;

        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.DarkGreen;

            Console.ForegroundColor = ConsoleColor.White;
            int n = 0, c = 0, elec = 0;
            Boolean valido = false;
            
            do
            {
                while (valido == false)
                {
                    try
                    {
                        Console.Write("¡Bienvenido!\nIngrese un entero para calcular esa cantidad de números\npertenecientes a la serie de Fibonnaci: ");
                n = int.Parse(Console.ReadLine());


                        tiempo1 = DateTime.Now;
                        Console.WriteLine("La serie es:");
                         fibonacciIte(n);
                        tiempo2 = DateTime.Now;//Se toma el tiempo al final de la serie
                       Console.WriteLine("Tiempo del Fibonacci Iteraitvo (ciclos): " + new TimeSpan(tiempo2.Ticks - tiempo1.Ticks));
                        tiempo1r = DateTime.Now;
                        fibonacciRec(n);
                        tiempo2r = DateTime.Now;
                        Console.WriteLine("Tiempo del Fibonacci Recursivo (llamarse nuevamente): " + new TimeSpan(tiempo2r.Ticks - tiempo1r.Ticks)); //Esto se hace llamado de la función recursiva

                if((tiempo2.Ticks - tiempo1.Ticks) > (tiempo2r.Ticks - tiempo1r.Ticks))
                {
                    Console.WriteLine("Tarda menos el recursivo\n\a");
                }
                else
                {
                    Console.WriteLine("Tarda menos el iterativo\n\a");
                }

                  

                while (valido == false)
                {
                    try {
                        Console.WriteLine("¿Desea calcular de nuevo?\n«0» para salir - otro entero para aceptar");
                        elec = int.Parse(Console.ReadLine());
                        valido = true;
                        }catch (Exception e){
                        Console.WriteLine(e);

                       valido = false;

                    }
                }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);

                        valido = false;

                    }
                }

            } while (elec != 0);

        }
        
        public static void fibonacciIte(int n)
        {
            int f1 = 0, f2 = 1, f3 = 0;
            for (int c = 0; c <= n; c++)
            {
                f3 = f1 + f2;

                int[] array = new int[n+1];
                array[c]=f3;
                Console.WriteLine(array[c]);
                f1 = f2;
                f2 = f3;
            }
        }

        public static int fibonacciRec(int n)

        {
            
            if ((n == 0) || (n == 1))
            {
                return 1;
        }
            else {
               
                return fibonacciRec(n - 1) + fibonacciRec(n - 2);
              
            
        }

    }

    }
    }
